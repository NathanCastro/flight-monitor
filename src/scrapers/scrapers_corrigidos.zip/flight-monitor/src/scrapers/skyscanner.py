"""
skyscanner.py — Scraper do Skyscanner.
"""

import logging
from datetime import datetime
from playwright.async_api import async_playwright
from .base import create_stealth_page, random_delay, parse_price

logger = logging.getLogger(__name__)

PRICE_SELECTORS = [
    '[data-testid="price-text"]',
    '[data-testid="price"]',
    '.BpkText_bpk-text--xl__MBAho',
    '[class*="Price_container"]',
    '[aria-label*="R$"]',
    '[class*="price"]',
]


def _build_url(origin: str, destination: str, date: str, passengers: int) -> str:
    d = datetime.strptime(date, "%Y-%m-%d")
    date_str = d.strftime("%y%m%d")
    return (
        f"https://www.skyscanner.com.br/transporte/passagens-aereas/"
        f"{origin.lower()}/{destination.lower()}/{date_str}/"
        f"?adults={passengers}&currency=BRL"
    )


async def scrape(origin: str, destination: str, date: str, passengers: int = 2) -> float | None:
    url = _build_url(origin, destination, date, passengers)
    logger.info(f"[Skyscanner] Buscando {origin}→{destination} em {date}: {url}")

    try:
        async with async_playwright() as pw:
            browser, page = await create_stealth_page(pw)
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
                await random_delay(3, 6)
                await page.evaluate("window.scrollBy(0, window.innerHeight * 0.6)")
                await random_delay(2, 4)

                prices = []
                for selector in PRICE_SELECTORS:
                    try:
                        elements = await page.query_selector_all(selector)
                        for el in elements:
                            text = await el.inner_text()
                            price = parse_price(text)
                            if price and 50 < price < 50_000:
                                prices.append(price)
                    except Exception:
                        continue

                if not prices:
                    logger.warning(f"[Skyscanner] Nenhum preço encontrado para {origin}→{destination}")
                    return None

                best = min(prices)
                logger.info(f"[Skyscanner] {origin}→{destination}: R$ {best:.2f} ({len(prices)} opções)")
                return best

            finally:
                await browser.close()

    except Exception as e:
        logger.error(f"[Skyscanner] Erro em {origin}→{destination}: {e}")
        return None
